# INTRO_SE_SP_2025
Introduction to Software Engineering Spring 2025 MSU
E-Commerce Platform Project
Team Member: Nathan Jones - NetID: ndj4, GITHUB: n8dog73, email: ndj4@msstate.edu
Roles: Project Manageer, Developer, Tester, and Editor. 

Project Description:
The E-Commerce Platform is a web application that will allow users to search, compare, buy and return different types of products from different sellers.  The platform will allow multiple sellers to sell their products on a platform that will reach many customers.  The customers will be able to search an abundant different products from their web browser.  Users, sellers, and administrators of the system will be able to access the system and components they wish from ease from a web browser. 

Objectives:
The E-Commerce Platform is a new system that developed from the ground up. Users will access the web interface to search for products from multiple sellers.  The sellers will have a separate web interface to add, sell, and receive payments. The administrators of the website will have a separate web interface to approve or block new user accounts and products as well as oversee other user actions. 

